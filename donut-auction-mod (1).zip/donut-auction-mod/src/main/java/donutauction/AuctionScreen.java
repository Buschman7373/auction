package donutauction;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** Menue zum Erstellen einer Auktion: Item aus dem Inventar waehlen oder Namen tippen. */
public class AuctionScreen extends Screen {
    private static final int SLOT = 18;

    private int gx;   // linke Kante des Inventar-Rasters
    private int top;  // obere Kante des Rasters
    private int fieldY;

    private int selectedSlot = -1;
    private ItemStack selectedStack = ItemStack.EMPTY;

    private TextFieldWidget itemField;
    private TextFieldWidget minutesField;
    private TextFieldWidget bidField;
    private String error = "";

    public AuctionScreen() {
        super(Text.literal("Auktion erstellen"));
    }

    private int slotX(int slot) {
        return slot < 9 ? gx + slot * SLOT : gx + ((slot - 9) % 9) * SLOT;
    }

    private int slotY(int slot) {
        return slot < 9 ? top + 3 * SLOT + 4 : top + ((slot - 9) / 9) * SLOT;
    }

    @Override
    protected void init() {
        int gridW = 9 * SLOT;
        gx = width / 2 - gridW / 2;
        top = 36;
        fieldY = top + 3 * SLOT + 4 + SLOT + 16;

        // 36 Slot-Buttons (Inventar + Hotbar); die Item-Icons werden in render() darueber gezeichnet
        for (int slot = 0; slot < 36; slot++) {
            final int s = slot;
            addDrawableChild(ButtonWidget.builder(Text.empty(), b -> select(s))
                    .dimensions(slotX(slot), slotY(slot), SLOT, SLOT)
                    .build());
        }

        itemField = new TextFieldWidget(textRenderer, gx, fieldY, gridW, 18, Text.literal("Item"));
        itemField.setMaxLength(64);
        itemField.setPlaceholder(Text.literal("Item waehlen oder Namen tippen"));
        addDrawableChild(itemField);

        minutesField = new TextFieldWidget(textRenderer, gx, fieldY + 32, 70, 18, Text.literal("Minuten"));
        minutesField.setMaxLength(8);
        minutesField.setText("10");
        addDrawableChild(minutesField);

        bidField = new TextFieldWidget(textRenderer, gx + 80, fieldY + 32, gridW - 80, 18, Text.literal("Startgebot"));
        bidField.setMaxLength(16);
        bidField.setText("1k");
        addDrawableChild(bidField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Starten"), b -> start())
                .dimensions(gx, fieldY + 58, 76, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Abbrechen"), b -> close())
                .dimensions(gx + 86, fieldY + 58, 76, 20).build());
    }

    private void select(int slot) {
        if (client == null || client.player == null) return;
        ItemStack stack = client.player.getInventory().getStack(slot);
        if (stack.isEmpty()) return;
        selectedSlot = slot;
        selectedStack = stack.copy();
        itemField.setText(stack.getName().getString());
        error = "";
    }

    private void start() {
        String item = itemField.getText().trim();
        if (item.isEmpty()) {
            error = "Bitte ein Item waehlen oder einen Namen eingeben.";
            return;
        }
        Double bid = AuctionMod.parseMoney(bidField.getText());
        if (bid == null) {
            error = "Ungueltiges Startgebot (z.B. 5000, 10k, 2.5m).";
            return;
        }
        double minutes;
        try {
            minutes = Double.parseDouble(minutesField.getText().trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            error = "Ungueltige Minutenzahl.";
            return;
        }
        if (minutes < 0.1) {
            error = "Mindestens 0.1 Minuten.";
            return;
        }
        AuctionMod.startAuction(item, selectedStack, bid, minutes);
        close();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        if (client == null || client.player == null) return;

        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "Item aus dem Inventar waehlen:", gx, top - 11, 0xFFAAAAAA);

        ItemStack hovered = ItemStack.EMPTY;
        for (int slot = 0; slot < 36; slot++) {
            ItemStack s = client.player.getInventory().getStack(slot);
            int x = slotX(slot);
            int y = slotY(slot);
            if (slot == selectedSlot) {
                ctx.fill(x, y, x + SLOT, y + SLOT, 0x9955FF55);
            }
            if (!s.isEmpty()) {
                ctx.drawItem(s, x + 1, y + 1);
                ctx.drawStackOverlay(textRenderer, s, x + 1, y + 1);
                if (mouseX >= x && mouseX < x + SLOT && mouseY >= y && mouseY < y + SLOT) {
                    hovered = s;
                }
            }
        }

        ctx.drawTextWithShadow(textRenderer, "Item-Name:", gx, fieldY - 11, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer, "Minuten:", gx, fieldY + 21, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer, "Startgebot:", gx + 80, fieldY + 21, 0xFFAAAAAA);

        if (!error.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, error, gx, fieldY + 84, 0xFFFF5555);
        }
        if (!hovered.isEmpty()) {
            ctx.drawItemTooltip(textRenderer, hovered, mouseX, mouseY);
        }
    }
}
