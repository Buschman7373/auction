DONUT AUCTION HELPER (Fabric, 1.21.11, nur Client)

SETUP
1. Gehe auf https://fabricmc.net/develop/template und erstelle ein Projekt fuer 1.21.11 (Java 21).
   Daraus brauchst du nur den Ordner "gradle/" sowie gradlew und gradlew.bat.
2. Kopiere diese Dateien in dasselbe Projekt (vorhandene ersetzen) und loesche aus dem Template
   die mitgelieferten Beispiel-Klassen/Mixins samt deren Eintraegen in fabric.mod.json.
3. Pruefe in gradle.properties die Versionen gegen https://fabricmc.net/develop.
4. Bauen:  ./gradlew build   -> fertige Mod in build/libs/ (die Datei OHNE "-sources").
5. Jar in den mods-Ordner legen (zusammen mit Fabric API).

BEFEHLE
/auction  oder  /auction menu          oeffnet das Auktionsmenue (Item waehlen, Minuten, Startgebot)
/auction start <minuten> <startgebot> <item>   z.B. /auction start 10 5k Diamantschwert
/auction status
/auction stop
/auction pattern <regex>    Zahlungsnachricht anpassen (Gruppe 1 = Name, Gruppe 2 = Betrag)
/auction fakebid <name> <betrag>   zum Testen ohne echte Zahlung

WICHTIG
- Das Standard-Muster fuer die Zahlungsnachricht ist geraten. Schau im Chat, wie eine echte
  Zahlung aussieht, und passe es mit /auction pattern an.
- Die Mod liest nur mit und zeigt an. Item uebergeben und Rueckzahlungen an Verlierer machst du selbst.
- Pruefe die Serverregeln, ob Client-Mods erlaubt sind.
